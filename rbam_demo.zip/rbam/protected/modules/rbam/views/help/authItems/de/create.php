<?php
/* SVN FILE: $Id: create.php 9 2010-12-17 13:21:39Z Chris $*/
/**
* Create Auth Item page help partial view.
* de version
* 
* @copyright	Copyright &copy; 2010 PBM Web Development - All Rights Reserved
* @package		RBAM
* @since			V1.0.0
* @version		$Revision: 9 $
* @license		BSD License (see documentation)
*/
?>
<h2>Erstellen Genehmigung Item</h2>
<p>Benutzen Sie das Formular, um eine neue Rolle, eine Aufgabe oder Betrieb zu schaffen.</p>
<p>Der Name und die Beschreibung erforderlich sind und der Name muss eindeutig sein.</p>
<p>Klicken Sie auf "Erstellen", um das Item zu erstellen.</p>
