<?php
/* SVN FILE: $Id: create.php 9 2010-12-17 13:21:39Z Chris $*/
/**
* Create Auth Item page help partial view.
* es version
* 
* @copyright	Copyright &copy; 2010 PBM Web Development - All Rights Reserved
* @package		RBAM
* @since			V1.0.0
* @version		$Revision: 9 $
* @license		BSD License (see documentation)
*/
?>
<h2>Crear elemento de la autorización</h2>
<p>Utilice el formulario para crear un nuevo función de trabajo, o la operación.</p>
<p>El nombre y la descripción son necesarios y el nombre debe ser único.</p>
<p>Haga clic en "Crear " para crear el elemento.</p>
