<?php
/* SVN FILE: $Id: _notInitialised.php 9 2010-12-17 13:21:39Z Chris $*/
/**
* RBAM home page "not initialised" partial view.
* de version
* 
* @copyright	Copyright &copy; 2010 PBM Web Development - All Rights Reserved
* @package		RBAM
* @since			V1.0.0
* @version		$Revision: 9 $
* @license		BSD License (see documentation)
*/
?>
<h2>RBAM Nicht Initialisierte</h2>
<p>Die Role Base Access Manager modul noch nicht initialisiert</p>
<p>Bitte ändern Sie die Modul-Konfiguration RBAM die Quelle der Daten angeben intitialisation, dann gehen Sie zu <?php echo Yii::app()->getRequest()->hostInfo.'/index.php?r=rbam'; ?></p> 
<p>Wenn Sie nicht sicher, was diese Meldung bedeutet, kontaktieren Sie bitte Ihren Systemadministrator</p>