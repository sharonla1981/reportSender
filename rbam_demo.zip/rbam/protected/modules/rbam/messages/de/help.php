<?php
/* SVN FILE: $Id: help.php 9 2010-12-17 13:21:39Z Chris $*/
/**
* Message translation file.
* Help messages. (Help files use file translation)
* en-gb
* 
* @copyright	Copyright &copy; 2010 PBM Web Development - All Rights Reserved
* @package		RBAM
* @since			V1.0.0
* @version		$Revision: 9 $
* @license		BSD License (see documentation)
*/
return array(
	'Role Based Access Manager Help'=>'Role Based Access Manager Hilfe',
	'Show help for this page'=>'Show für diese Seite Hilfe',
);